# Nebula Alerts — ArcGIS to SharePoint

Prepared 16 October 2026. Python 3.10+. This is a complete implementation for internal testing, with offline behavioural tests. It has **not** been authenticated against your company's ArcGIS or Microsoft 365 tenant. No company credentials were used and no SharePoint items were created during preparation.

## What to do first

1. Rotate both passwords exposed in the original snippet. Remove the old `nebula_arcgis.tmp` file from any machine where the original code ran, and remove hardcoded credentials from retained code copies.
2. Ask IT for an approved Entra application identity and selected access to **Nebula Alerts**. The IT request below describes exactly what is needed. Replacing a Python library cannot override tenant authentication or network policy.
3. Have the list owner add **AlertKey**, and check the column definitions below.
4. Copy `config.example.json` to `config.json`; review the event selection assumptions, then run the read-only checks and dry run before the first write.

## Why the original approach can fail

A corporate GPT being blocked while generating text is not evidence that Python reached SharePoint. It could be a content/DLP control, a connector restriction, or something else; the block message is needed to determine the cause. Separately, a running script can fail at DNS, proxy, TLS, authentication, authorisation or payload validation.

The original password logic tests whether `ARCGIS_PASSWORD` exists but assigns a hardcoded value instead of using the environment value. Its fixed plaintext temporary password file also introduces unnecessary exposure and overlapping-run races. This version reads secrets from the process environment and keeps tokens in memory.

The SharePoint sharing link beginning `/:l:/r/` is not the site base URL. The canonical site is:

`https://xlgroupcrmeur.sharepoint.com/teams/GIS90`

The implementation uses Microsoft Graph with an approved application identity. It does not use your Microsoft 365 username/password, legacy cookie authentication, SMTP, Teams webhooks or `Office365-REST-Python-Client`. That library is not inherently the problem; the proposed user/password authentication flow is unsuitable when the tenant requires controls it cannot satisfy. [1–3]

## Behaviour and deliberate choices

- Each execution performs one scan. Windows Task Scheduler or an equivalent approved scheduler starts it every 30 minutes.
- Eight threads perform network-bound intersections. Each thread has its own HTTP session and ArcGIS token cache. The intersection runs on ArcGIS Server, so CPU-heavy Python multiprocessing and password-file distribution are unnecessary here.
- ArcGIS Portal credentials are exchanged for a portal token, then a server-specific token for the configured federated server. Public ArcGIS Online requests receive **no Enterprise token**. Standalone, non-federated ArcGIS Server or IWA/SAML-only configurations need a different authentication adapter. [4]
- Event features sharing a stable event ID are grouped. The script queries portfolio feature IDs for each polygon, then unions those IDs. An insured point overlapping several swaths/perimeters is counted once per event and portfolio.
- `esriSpatialRelIntersects` includes boundary points. Event geometry is requested in EPSG:4326 and the query explicitly specifies that spatial reference. ArcGIS performs the spatial query against the portfolio layer.
- Counts mean unique **portfolio feature rows**, deduplicated by OBJECTID. This assumes one feature per insured location. If `Locid` is duplicated across rows, deduplicate the portfolio upstream or agree a business-ID counting rule before deployment. AccountName is not assumed unique.
- IDs are cross-checked against a count query. Attribute/geometry retrieval uses small ID batches and verifies all requested features returned. Transfer limits, missing features and detected mid-query changes become errors rather than zero counts. Even object-ID arrays have limits in current ArcGIS services. [5]
- `AffectedLocations` is an explicit preview of the first 100 affected features, shown as `AccountName [Locid]`; the full count is retained. It also has a text-length cap. Truncation is labelled. Raise `affected_location_limit` if needed; use a related list or approved file export for a complete large location-level extract.
- One SharePoint item represents the current status of an **event source + stable event ID + portfolio source**. The script creates a row if absent and updates it on later checks. It also writes one `[Source health]` row per enabled source/portfolio, using reserved EventID `__SOURCE__`.
- Every completed check updates Timestamp in UTC, including unchanged breaches. It is the analysis check time, not the event's observation/forecast time or the SharePoint delivery time.
- State and a FIFO delivery queue are saved atomically before SharePoint writes. Failed writes stay queued. Subsequent runs replay updates in order; `AlertKey` and its unique constraint protect against duplicate creation after an ambiguous network failure. Delivery is at least once: a successful PATCH can be replayed after a crash.
- This is a current-status list, not an immutable alert-history log. Enable SharePoint versioning with an appropriate retention policy if useful. If you later add a notification flow, account for repeated unchanged updates and delayed queue replays; inspect the timestamp and status/count transition.

### Status meanings

| Status | Meaning |
|---|---|
| BREACH | Successful count >= portfolio threshold and <= sanity threshold. |
| CLEAN | Successful below-threshold count, with no previous confirmed breach to resolve. Source-health CLEAN means only that its event query succeeded. |
| ALL CLEAR | Successful below-threshold analysis after a confirmed breach. Remains ALL CLEAR while below threshold. If the threshold is >1, this can mean a nonzero count. |
| SUSPECT | Count exceeds 15,000 by default. Needs review; does not erase the last confirmed breach. A large count may be legitimate. |
| ERROR | Query/configuration/data failure, or an event disappeared from the selected feed/window. Count is blank, not zero. |
| TIMEOUT | A connection/read timeout occurred. Count is blank; previous confirmed breach state is retained. |

**Disappearance does not mean all-clear.** A feed can stop publishing an event, lose data or roll it out of a time window. This implementation marks the previous event uncertain. If your business policy should retire such events, add a separate, agreed retirement workflow/status; do not silently translate disappearance into physical safety.

Source-health rows are operational markers. Exclude EventID `__SOURCE__` from exposure charts. A successful empty query does not prove the upstream feed is fresh or complete.

## Review these configuration assumptions

The public hurricane endpoint supplied in the request was inspected on 16 October 2026. Layer 2 is **Observed Wind Swath**, a polygon layer, with `STORMNAME`, `STORMID`, `STARTDTG`, `ENDDTG` and `RADII` fields. It is not a forecast track line or forecast cone. The example selects `RADII >= 34` and events/features with `ENDDTG` in the last **72 hours**. This is a configurable retrospective monitoring window, not an asserted definition of a live storm. [6]

An observed swath may represent cumulative wind exposure. Selecting by its end date does not clip the geometry to only the last 72 hours. For advance warning, select and validate the appropriate forecast hazard polygon layer and its validity/lead-time fields. Wind radii, a track buffer and a forecast cone have different meanings.

The Texas July 2026 flood layer is retained as a **disabled static test** because its supplied name describes a historical snapshot. Its private contents were not inspected. You can enable it for deliberate testing; replace it with your live feed and an approved active-event/date filter for operational use. A Texas footprint intersecting a Florida portfolio should usually yield zero, so it is a weak positive-path test.

Australia, Philippines and wildfire entries are included disabled. Enabling a portfolio also requires an enabled event whose `portfolios` array contains that portfolio key. This explicit pairing avoids automatically treating every hazard as insured under every peril. Confirm coverage/business suitability: spatial overlap alone does not prove coverage, damage or financial loss.

For wildfire, confirm whether `GeometryID` identifies a stable incident or a particular geometry revision. A changing geometry ID is unsuitable for tracking one incident across runs; use a stable incident identifier instead. `where: "1=1"` does not establish that an event is live. Configure an active-status filter or a supported date field/lookback before enabling that source operationally.

Private-layer field names and authentication have not been verified. `--check-arcgis` validates enabled layer geometry types and exact field names. Event IDs must be stable, nonblank, unique per incident within each source, and must not equal the reserved `__SOURCE__` value. A source URL/key change creates new identities; disabling/removing a source stops updates to its old rows. Use timestamps and an agreed archival process for those rows.

## SharePoint list setup

Use the actual **internal** field names returned by Graph. Display labels can differ. If necessary map them in `sharepoint.field_map`, for example `{"EventName": "Event_x0020_Name"}`. The diagnostic prints internal names and labels without reading item contents. [7]

| Logical field | Required list type/settings |
|---|---|
| Title | Single line of text; existing default Title column |
| EventName | Single line of text |
| EventID | Single line of text, even if some feeds have numeric IDs |
| Region | Single line of text |
| Count | Number, 0 decimals; **optional/blank allowed**, no minimum validation that rejects null |
| Threshold | Number, 0 decimals |
| Status | Single-choice: BREACH, ALL CLEAR, CLEAN, SUSPECT, ERROR, TIMEOUT |
| AlertReason | **Multiple lines of plain text**, append changes disabled |
| AffectedLocations | **Multiple lines of plain text**, append changes disabled; optional |
| Timestamp | Date and Time, including time |
| **AlertKey** | **New single-line text** column, length >=64, indexed, **Enforce unique values = Yes** |

Do not make additional list columns mandatory unless the script populates them. Do not change AlertKey values on managed rows. Existing unkeyed rows from earlier scripts are not automatically adopted; resolve/archive them before the first production run.

The script intentionally does not create the list or change permissions/schema. Use the list owner/admin to make these setup changes. Graph writes are `POST .../items` for new rows and `PATCH .../items/{id}/fields` for existing rows. [8–9]

## IT setup request

Request an approved unattended Python job that reads selected ArcGIS event/portfolio services and writes derived exposure alerts to **Nebula Alerts**, at `https://xlgroupcrmeur.sharepoint.com/teams/GIS90`.

Ask IT to provide:

1. An Entra app registration, its **tenant ID** and **client/application ID**, and an approved certificate credential. Register the public certificate in Entra; keep the private PEM key accessible only to the job account. A short-lived client secret from the corporate secret store is an implemented alternative if IT prefers it.
2. Microsoft Graph **application** permission `Lists.SelectedOperations.Selected`, with administrator consent, plus an explicit **write** grant for the Nebula Alerts list. Consent alone grants no access. IT may instead choose `Sites.Selected` with a write grant to this site if that is its supported pattern; that grants a wider site scope. Do not request tenant-wide write access for the running job. [1]
3. The site's **Graph site ID** and the list's GUID. They are not the sharing-link token. The script calls the known list directly so a list-scoped app does not need to enumerate sites/lists.
4. A read-only ArcGIS service account able to query the selected layers, instead of the built-in administrator account. This adapter assumes Portal built-in token authentication with a federated server.
5. An approved runner, proxy settings if required, and the appropriate trusted CA bundle. The bundle must cover both the internal/corporate trust chain and public HTTPS endpoints. Do not disable certificate verification.
6. Approved outbound HTTPS access from that runner to `login.microsoftonline.com`, `graph.microsoft.com`, the Enterprise GIS host and the configured public ArcGIS host. Any additional identity discovery/PKI endpoints should follow IT's standard Microsoft/Esri allow-list guidance. A user's browser reaching SharePoint does not establish that an unattended runner can call Graph.

For the **administrator's provisioning process**, Microsoft documents the list grant as:

```http
POST https://graph.microsoft.com/v1.0/sites/{site-id}/lists/{list-id}/permissions
Content-Type: application/json

{
  "grantedToV2": {
    "application": {
      "id": "<NEBULA-APPLICATION-CLIENT-ID>",
      "displayName": "Nebula Alerts Monitor"
    }
  },
  "roles": ["write"]
}
```

The identity making this grant needs the administrator's appropriate provisioning permissions; the monitor must not grant itself permissions. List-scoped application grants also affect permission inheritance, so the list owner should review this during setup. [1, 10]

If needed, IT can resolve the IDs with authorised Graph calls:

```http
GET https://graph.microsoft.com/v1.0/sites/xlgroupcrmeur.sharepoint.com:/teams/GIS90
GET https://graph.microsoft.com/v1.0/sites/{returned-site-id}/lists?$select=id,displayName,webUrl
```

Match **Nebula Alerts** and its web URL. The running list-scoped app is not expected to have permission to perform these discovery calls. [11–12]

## Install and configure on the approved runner

Use a dedicated environment and your company's approved package source. In PowerShell, from the extracted project directory:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item config.example.json config.json
```

Edit `config.json` for the approved event definitions, fields and portfolios. Set these variables in the job's environment through your company's secret-management/deployment mechanism:

| Variable | Value |
|---|---|
| ARCGIS_USERNAME | Approved Portal service-account username |
| ARCGIS_PASSWORD | Rotated Portal account password |
| M365_TENANT_ID | Entra tenant GUID or approved tenant domain |
| M365_CLIENT_ID | Entra application/client GUID |
| M365_SITE_ID | Graph site identifier, normally hostname,siteCollectionGuid,webGuid |
| M365_LIST_ID | Nebula Alerts list GUID |
| M365_CERT_PRIVATE_KEY_PATH | Absolute path to protected PEM private key |
| M365_CERT_THUMBPRINT | Registered certificate thumbprint |
| M365_CERT_PASSPHRASE | Optional passphrase for an encrypted PEM key |
| M365_CLIENT_SECRET | Alternative to certificate variables; not a user password |
| NEBULA_CA_BUNDLE | Optional absolute path to an approved PEM CA bundle; otherwise Requests' trusted bundle is used |
| HTTPS_PROXY / NO_PROXY | Only the runner's approved proxy configuration, if needed |

`site_id` and `list_id` in the JSON can alternatively contain the non-secret IDs; nonempty config values take precedence over environment values. `REQUESTS_CA_BUNDLE` is also recognised. No `.env` file is loaded automatically. No interactive password prompt is used. Do not place secrets in shell history, the configuration file, screenshots or support messages.

Run these in order:

```powershell
.\.venv\Scripts\python.exe nebula_monitor.py --config config.json --check-arcgis
.\.venv\Scripts\python.exe nebula_monitor.py --config config.json --check-sharepoint
.\.venv\Scripts\python.exe nebula_monitor.py --config config.json --dry-run
```

The ArcGIS check reads enabled layer metadata; the SharePoint check authenticates and reads the column schema. Neither writes to SharePoint. The latter proves read/schema access, **not write permission**. Confirm the explicit write grant and test the first write in your approved test list.

The dry run performs actual spatial queries and creates `runtime/dry_run_results.json`. It does not modify the state/outbox or contact SharePoint. Compare a known positive and known negative case against an ArcGIS map/query; include an overlapping-polygon case and a boundary point. An empty current hurricane feed is not a sufficient positive-path test.

Once the configuration and test results are accepted, the normal command writes to the configured list:

```powershell
.\.venv\Scripts\python.exe nebula_monitor.py --config config.json
```

### Schedule every 30 minutes

In Windows Task Scheduler, create a task under the approved service identity:

- Trigger: repeat every 30 minutes, indefinitely.
- Program: the absolute path to `.venv\Scripts\python.exe`.
- Arguments: absolute path to `nebula_monitor.py`, followed by `--config` and the absolute path to `config.json`; quote paths containing spaces.
- Start in: the project directory.
- Run whether the user is logged on or not, using IT's approved account setup.
- If already running: **Do not start a new instance**. Use one runner and one local runtime directory.
- Set an appropriate hard execution limit (for example 25 minutes after confirming expected runtime) and monitor missed runs/nonzero exit codes.

The script has a local OS-backed lock, per-request connection/read timeouts and bounded retries. It does **not** implement a hard wall-clock deadline for a thread or whole run; read timeouts are inactivity timeouts and do not forcibly terminate an arbitrarily long scan. The scheduler supplies the hard limit. If interrupted, the previous durable state remains; a later run safely replays pending writes. [13]

## Diagnose the actual failure

| Evidence | Interpretation / next action |
|---|---|
| Secure GPT stops while generating text, before any Python execution | Obtain its block message/reference for the corporate GPT support team. This alone is not a network diagnosis. |
| TLS certificate validation error | Fix the trust chain/bundle with IT; do not use `verify_cert=False`. |
| DNS/connection failure, proxy failure or timeout | Check runner network/proxy route and destination allow-list. Timeout alone does not prove a firewall block. |
| HTTP 407 | Proxy authentication/configuration issue. |
| HTTP 401 / invalid_client / Entra error | Check app credential, tenant, token audience, credential expiry and relevant tenant policy. |
| HTTP 403 accessDenied | The request received a denial; check selected permission consent **and** resource grant, role and tenant policy. A proxy can also return 403, so inspect its provenance with IT. |
| HTTP 404 | Wrong site/list ID, removed resource, or access-hidden resource. |
| HTTP 400 on write | Check internal field names, column types, required fields, choices, validation rules and text limits. |
| HTTP 429 | Throttled. Retry-After is honoured for short delays; longer waits defer delivery to the next run. [13] |
| HTTP 200 containing HTML instead of JSON | Possible sign-in page, proxy or security block response; have IT inspect it locally. |
| ArcGIS ID/count mismatch or incomplete feature batch | Truncation or detected source changes; keep the error and retry a later snapshot. |

Share only the command/mode, exception category, HTTP/provider code, request/correlation ID and approximate time with support. Do not share passwords, tokens, private keys, raw confidential responses or affected location names. Error messages deliberately omit raw request/response bodies; IT may need deeper local diagnostics for an unexpected failure.

Exit codes: **0** completed; **1** fatal setup/delivery failure; **2** analysis needs attention (ERROR/TIMEOUT/SUSPECT); **3** delivery queue still has pending records; **4** overlapping run skipped. A BREACH itself is a successful monitor result and does not make the job fail.

## State, operation and limits

`runtime/nebula_state.json` stores the last observations, confirmed breach state and undelivered writes. `latest_results.json` holds the latest scan. These can contain confidential account/location names: use approved local storage, restricted permissions, backup and retention. Do not put runtime data in a public repository or sync it to an unapproved location. On Windows, configure NTFS permissions; do not rely on POSIX file modes.

Use a durable local runtime directory, not a temporary directory. The state format is new and does not import the incomplete original script's state files. The first run starts a new baseline. Restoring/resetting state can alter new/resolved classifications; preserve and restore the full state/outbox together.

The outbox is FIFO and stops at the first failed write. Investigate a bad payload promptly because it blocks later delivery. At the configured 10,000-record high-water mark the job attempts to drain the queue before another scan, and fails visibly if delivery is still blocked. This is a high-water safeguard, not an exact row cap. Monitor queue growth and stale Timestamp values; old updates can be delivered after an outage.

Only one runner should own a state directory/list deployment. The local lock is not a distributed lease. Do not run concurrent hosts or let separate applications overwrite these managed rows without a coordination design. This implementation does not use ETags for multi-writer conflict resolution.

ArcGIS queries do not form a database-wide snapshot. Count/ID checks catch some races, not geometry changes with unchanged counts/IDs. For stronger consistency, use a versioned event snapshot, historic-moment queries where supported, or a staged event feed. Health checks do not independently validate upstream publication freshness. Agree a source-specific validity/freshness policy with the feed owner.

The old `ALERT_MODE`, digest hour and digest state are not used because this delivery path writes the list every scan. No email or Teams notification is sent. Once list delivery is approved, a separately approved Power Automate flow could act on list changes; it remains subject to your tenant's connector/DLP policies.

If IT cannot approve Graph access from this runner, the monitor can still run in dry-run mode. Agree an approved transfer pattern with IT, such as a managed job or approved Power Automate ingestion route. A local JSON file does not by itself update SharePoint, and the code cannot legitimately override tenant restrictions.

## Validation performed

Run the supplied offline tests with:

```powershell
.\.venv\Scripts\python.exe -m unittest -v test_nebula.py
```

The tests cover overlapping polygons, grouping multiple polygons per storm, pagination and incomplete queries, spatial reference checks, truncated name previews, threshold transitions, changed affected sets, query errors/timeouts, missing events, durable queue retention, ambiguous write replay, Graph create/update selection, credential routing and dry-run isolation. They use mocks; they do not prove network access, actual geometry correctness on your services or tenant write permissions. Live integration testing must be performed in your approved environment.

## Official references

1. [Microsoft: selected permissions, consent and resource grants](https://learn.microsoft.com/en-us/graph/permissions-selected-overview)
2. [Microsoft: MSAL Python client credentials](https://learn.microsoft.com/en-us/entra/msal/python/advanced/client-credentials)
3. [Microsoft: username/password flow constraints](https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth-ropc)
4. [Esri: generateToken and federated-server token exchange](https://developers.arcgis.com/rest/users-groups-and-items/generate-token/)
5. [Esri: feature-layer query, geometry filters and result limits](https://developers.arcgis.com/rest/services-reference/enterprise/query-feature-service-layer/)
6. [Supplied hurricane layer metadata](https://services9.arcgis.com/RHVPKKiFTONKtxq3/ArcGIS/rest/services/Recent_Hurricanes_v1/FeatureServer/2?f=pjson)
7. [Microsoft: columnDefinition and internal column names](https://learn.microsoft.com/en-us/graph/api/resources/columndefinition?view=graph-rest-1.0)
8. [Microsoft: create a list item](https://learn.microsoft.com/en-us/graph/api/listitem-create?view=graph-rest-1.0)
9. [Microsoft: update list-item fields](https://learn.microsoft.com/en-us/graph/api/listitem-update?view=graph-rest-1.0)
10. [Microsoft: grant an application access to a list](https://learn.microsoft.com/en-us/graph/api/list-post-permissions?view=graph-rest-1.0)
11. [Microsoft: resolve a site by path](https://learn.microsoft.com/en-us/graph/api/site-getbypath?view=graph-rest-1.0)
12. [Microsoft: enumerate lists](https://learn.microsoft.com/en-us/graph/api/list-list?view=graph-rest-1.0)
13. [Microsoft: throttling and Retry-After](https://learn.microsoft.com/en-us/graph/throttling)
