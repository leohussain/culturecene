#!/usr/bin/env python3
"""ArcGIS intersections -> durable local outbox -> SharePoint current-state list.

Run once per scheduler invocation. See README.md before deployment.
No credentials are embedded, prompted for, or written to a temporary file.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import logging
import os
import re
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from urllib.parse import quote, urlsplit

import requests
from filelock import FileLock, Timeout as LockTimeout

LOG = logging.getLogger("nebula")
STATUSES = {"BREACH", "ALL CLEAR", "CLEAN", "SUSPECT", "ERROR", "TIMEOUT"}
FIELDS = ("Title", "EventName", "EventID", "Region", "Count", "Threshold",
          "Status", "AlertReason", "AffectedLocations", "Timestamp", "AlertKey")
GRAPH = "https://graph.microsoft.com/v1.0"


class MonitorError(Exception):
    pass


class QueryTimeout(MonitorError):
    pass


class HttpFailure(MonitorError):
    def __init__(self, status, message):
        self.status = status
        super().__init__(message)


def utcnow():
    return datetime.now(timezone.utc)


def stamp():
    return utcnow().isoformat(timespec="seconds").replace("+00:00", "Z")


def required_env(name):
    value = os.environ.get(name, "")
    if not value.strip():
        raise MonitorError(f"Missing environment variable: {name}")
    return value


def https_url(url):
    parts = urlsplit(url)
    if parts.scheme != "https" or not parts.hostname or parts.username or parts.password:
        raise MonitorError("All service URLs must use HTTPS without embedded credentials")
    if parts.query or parts.fragment:
        raise MonitorError("Use a canonical service URL without a query or fragment")
    return url.rstrip("/")


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False).encode()).hexdigest()


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(data, output, indent=2, ensure_ascii=False, allow_nan=False)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def load_state(path):
    if not Path(path).exists():
        return {"version": 1, "records": {}, "outbox": []}
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise MonitorError("State is unreadable; restore its backup, do not reset it silently") from exc
    if (data.get("version") != 1 or not isinstance(data.get("records"), dict)
            or not isinstance(data.get("outbox"), list)):
        raise MonitorError("Unsupported or corrupt state file")
    return data


def retry_delay(value, attempt):
    if not value:
        return min(2 ** attempt, 8)
    try:
        return max(0, float(value))
    except ValueError:
        try:
            return max(0, (parsedate_to_datetime(value) - utcnow()).total_seconds())
        except (ValueError, TypeError):
            return min(2 ** attempt, 8)


class Http:
    """One instance per thread; bounded connect/read waits, no raw response logging."""
    def __init__(self, config):
        self.session = requests.Session()  # honours approved HTTPS_PROXY / NO_PROXY
        self.verify = os.environ.get("NEBULA_CA_BUNDLE") or os.environ.get("REQUESTS_CA_BUNDLE") or True
        self.timeout = (config.get("connect_timeout_seconds", 10),
                        config.get("read_timeout_seconds", 60))

    def request(self, method, url, *, retryable=True, **kwargs):
        host = urlsplit(url).hostname
        for attempt in range(3 if retryable else 1):
            try:
                response = self.session.request(method, url, timeout=self.timeout,
                                                verify=self.verify, allow_redirects=False, **kwargs)
            except requests.exceptions.SSLError as exc:
                raise MonitorError(f"TLS certificate validation failed for {host}; check the approved CA bundle") from exc
            except requests.exceptions.ProxyError as exc:
                raise MonitorError(f"Proxy connection failed for {host}") from exc
            except requests.exceptions.Timeout as exc:
                raise QueryTimeout(f"Connection/read timeout for {host}") from exc
            except requests.exceptions.ConnectionError as exc:
                raise MonitorError(f"Network/DNS connection failed for {host}") from exc
            except requests.exceptions.RequestException as exc:
                raise MonitorError(f"HTTP client failure for {host}") from exc
            if response.status_code in (429, 502, 503, 504) and retryable and attempt < 2:
                delay = retry_delay(response.headers.get("Retry-After"), attempt)
                if delay > 30:
                    raise HttpFailure(response.status_code, f"{host} requested a retry later; deferred to next run")
                response.close()
                time.sleep(delay)
                continue
            if not 200 <= response.status_code < 300:
                # Do not print URLs, bearer tokens, HTML block pages or response bodies.
                code = ""
                try:
                    code = str(response.json().get("error", {}).get("code", ""))
                except (ValueError, AttributeError):
                    pass
                code = re.sub(r"[^A-Za-z0-9_.-]", "", code)[:80]
                request_id = re.sub(r"[^A-Za-z0-9-]", "", response.headers.get("request-id", ""))[:80]
                raise HttpFailure(response.status_code,
                                  f"HTTP {response.status_code} from {host}; code={code}; request-id={request_id}")
            if response.status_code == 204:
                return {}
            try:
                body = response.json()
            except ValueError as exc:
                raise MonitorError(f"Non-JSON response from {host}; possible proxy/sign-in/block page") from exc
            if not isinstance(body, dict):
                raise MonitorError(f"Unexpected JSON response from {host}")
            return body
        raise MonitorError("Retry budget exhausted")


class ArcGIS:
    def __init__(self, config):
        self.config = config
        self.portal = https_url(config["arcgis"]["portal_url"])
        self.http = Http(config)
        self.http.session.headers["Referer"] = self.portal
        self.tokens = {}
        self.metadata = {}

    def generate(self, data):
        reply = self.http.request("POST", self.portal + "/sharing/rest/generateToken",
                                  data={"f": "json", **data})
        if "error" in reply or not reply.get("token"):
            code = reply.get("error", {}).get("code", "unknown")
            raise MonitorError(f"ArcGIS token acquisition failed (code {code}); check account/authentication")
        return reply["token"], reply.get("expires", time.time() * 1000 + 600000) / 1000

    def token(self, server_url):
        server_url = https_url(server_url)
        allowed = self.config["arcgis"]["allowed_server_urls"]
        if server_url not in [https_url(url) for url in allowed]:
            raise MonitorError("Refused ArcGIS authentication to a server outside allowed_server_urls")
        if "portal" not in self.tokens or self.tokens["portal"][1] < time.time() + 120:
            self.tokens.clear()
            self.tokens["portal"] = self.generate({
                "username": required_env("ARCGIS_USERNAME"),
                "password": required_env("ARCGIS_PASSWORD"),
                "client": "referer", "referer": self.portal, "expiration": 60})
        if server_url not in self.tokens or self.tokens[server_url][1] < time.time() + 120:
            self.tokens[server_url] = self.generate({
                "token": self.tokens["portal"][0], "serverUrl": server_url})
        return self.tokens[server_url][0]

    def call(self, layer, suffix="", **params):
        url = https_url(layer["url"])
        auth = layer.get("auth", "public")
        server = layer.get("server_url", "")
        if auth == "portal" and not url.startswith(https_url(server) + "/rest/services/"):
            raise MonitorError("Authenticated layer URL is not below its configured server_url")
        for attempt in range(2):
            data = {"f": "json", **params}
            if auth == "portal":
                data["token"] = self.token(server)
            elif auth != "public":
                raise MonitorError("Layer auth must be public or portal")
            try:
                reply = self.http.request("POST", url + suffix, data=data)
            except HttpFailure as exc:
                if exc.status in (498, 499) and auth == "portal" and attempt == 0:
                    self.tokens.clear()
                    continue
                raise
            error = reply.get("error")
            if not error:
                return reply
            if error.get("code") in (498, 499) and auth == "portal" and attempt == 0:
                self.tokens.clear()
                continue
            raise MonitorError(f"ArcGIS layer request failed (code {error.get('code', 'unknown')})")
        raise MonitorError("ArcGIS token refresh failed")

    def meta(self, layer, geometry_type):
        key = layer["url"]
        if key not in self.metadata:
            data = self.call(layer)
            if data.get("geometryType") != geometry_type:
                raise MonitorError(f"Expected {geometry_type}; received {data.get('geometryType')}")
            names = {field["name"] for field in data.get("fields", [])}
            for name in (layer["id_field"], layer["name_field"], layer.get("time_field")):
                if name and name not in names:
                    raise MonitorError(f"Layer field missing (case-sensitive): {name}")
            if not data.get("objectIdField"):
                raise MonitorError("Layer must expose a standard objectIdField")
            self.metadata[key] = data
        return self.metadata[key]

    def ids(self, layer, **params):
        query = {"where": layer.get("where", "1=1"), **params}
        response = self.call(layer, "/query", returnIdsOnly="true", **query)
        if response.get("exceededTransferLimit") or not isinstance(response.get("objectIds"), list):
            raise MonitorError("Incomplete or invalid ArcGIS object ID response")
        ids = set(response["objectIds"])
        if not all(isinstance(value, int) and not isinstance(value, bool) for value in ids):
            raise MonitorError("Only standard integer ArcGIS object IDs are supported")
        # ID arrays also have service limits. Cross-check instead of assuming unlimited IDs.
        count = self.call(layer, "/query", returnCountOnly="true", **query).get("count")
        if count != len(ids):
            raise MonitorError("ArcGIS ID/count mismatch: truncated query or data changed during retrieval")
        return ids

    def features(self, layer, ids, out_fields, geometry=False):
        if not ids:
            return []
        meta = self.metadata[layer["url"]]
        oid = meta["objectIdField"]
        size = min(200, int(meta.get("maxRecordCount", 200)))
        if size < 1:
            raise MonitorError("Invalid layer maxRecordCount")
        all_ids = sorted(ids)
        found = []
        for start in range(0, len(all_ids), size):
            batch = all_ids[start:start + size]
            reply = self.call(layer, "/query", objectIds=",".join(map(str, batch)),
                              outFields=",".join(sorted(set(out_fields) | {oid})),
                              returnGeometry=str(geometry).lower(), outSR=4326,
                              returnTrueCurves="false")
            features = reply.get("features", [])
            returned = {f.get("attributes", {}).get(oid) for f in features}
            if reply.get("exceededTransferLimit") or returned != set(batch) or len(features) != len(batch):
                raise MonitorError("Incomplete feature batch: data changed or server truncated the result")
            if geometry:
                sr = reply.get("spatialReference")
                for feature in features:
                    shape = feature.get("geometry")
                    if not shape or not shape.get("rings"):
                        raise MonitorError("Missing or invalid event polygon geometry")
                    shape.setdefault("spatialReference", sr or {"wkid": 4326})
                    actual = shape["spatialReference"]
                    if actual.get("latestWkid", actual.get("wkid")) != 4326:
                        raise MonitorError("Event geometry was not returned in requested EPSG:4326")
            found.extend(features)
        return found


def event_where(event, now=None):
    where = event.get("where", "1=1")
    if event.get("lookback_hours"):
        if not event.get("time_field"):
            raise MonitorError("lookback_hours needs a time_field")
        cutoff = (now or utcnow()) - timedelta(hours=float(event["lookback_hours"]))
        literal = cutoff.strftime("%Y-%m-%d %H:%M:%S")
        where = f"({where}) AND {event['time_field']} >= TIMESTAMP '{literal}'"
    return where


def read_events(client, event):
    meta = client.meta(event, "esriGeometryPolygon")
    ids = client.ids(event, where=event_where(event))
    features = client.features(event, ids, [event["id_field"], event["name_field"]], True)
    grouped = {}
    for feature in features:
        attrs = feature["attributes"]
        value = attrs.get(event["id_field"])
        if value is None or not str(value).strip():
            raise MonitorError("Event ID is blank; configure a stable, non-null event identifier")
        event_id = str(value).strip()
        if event_id == "__SOURCE__":
            raise MonitorError("Event ID conflicts with reserved source-health identifier")
        item = grouped.setdefault(event_id, {"id": event_id,
                                            "name": str(attrs.get(event["name_field"]) or event_id),
                                            "polygons": []})
        item["polygons"].append(feature["geometry"])
    LOG.info("Event source %s: %s polygon features, %s grouped events (%s)",
             event["key"], len(ids), len(grouped), meta.get("name", ""))
    return grouped


def intersect(client, portfolio, polygons, config):
    meta = client.meta(portfolio, "esriGeometryPoint")
    affected = set()
    for polygon in polygons:
        affected |= client.ids(portfolio, geometry=json.dumps(polygon, separators=(",", ":")),
                               geometryType="esriGeometryPolygon", inSR=4326,
                               spatialRel="esriSpatialRelIntersects")
    count = len(affected)  # each portfolio feature counted once across all event polygons
    limit = config.get("affected_location_limit", 100)
    selected = sorted(affected)[:limit]
    features = client.features(portfolio, selected, [portfolio["id_field"], portfolio["name_field"]])
    features.sort(key=lambda f: f["attributes"][meta["objectIdField"]])
    labels = []
    for feature in features:
        attrs = feature["attributes"]
        location_id = str(attrs.get(portfolio["id_field"]) or attrs[meta["objectIdField"]])
        name = attrs.get(portfolio["name_field"])
        labels.append(f"{name} [{location_id}]" if name else location_id)
    text = ", ".join(labels)
    truncated = len(selected) < count or len(text) > 12000
    if len(text) > 12000:
        text = text[:12000]
    if truncated:
        text += " … [truncated; Count is the full count]"
    return {"count": count, "locations": text, "fingerprint": digest(sorted(affected)),
            "truncated": truncated}


def record_key(event, portfolio, event_id):
    # URLs intentionally included: repointing a source must not silently reuse old rows.
    return digest([event["key"], event["url"], portfolio["key"], portfolio["url"], event_id])


def result_record(event, portfolio, event_id, name, outcome, previous, config, timestamp):
    threshold = portfolio.get("threshold", config.get("global_threshold", 1))
    active = previous.get("active_breach", False)
    reason = outcome.get("error")
    count = outcome.get("count")
    if reason:
        status = outcome.get("status", "ERROR")
    elif count > config.get("suspect_count_threshold", 15000):
        status = "SUSPECT"
        reason = "Sanity threshold exceeded; review the count and geometry. Not a confirmed all-clear."
    elif count >= threshold:
        status = "BREACH"
        if not active:
            reason = "New breach: location count meets or exceeds the alert threshold."
        elif count != previous.get("last_good_count"):
            reason = f"Breach count changed from {previous.get('last_good_count')} to {count}."
        elif outcome.get("fingerprint") != previous.get("last_good_fingerprint"):
            reason = "Affected portfolio features changed; total count is unchanged."
        else:
            reason = "Breach remains active."
        active = True
    elif active or previous.get("fields", {}).get("Status") == "ALL CLEAR":
        status = "ALL CLEAR"
        reason = "Successful analysis is below threshold; the previous breach is resolved."
        active = False
    else:
        status = "CLEAN"
        reason = "Successful analysis is below the alert threshold."
        active = False
    if outcome.get("truncated"):
        reason += " AffectedLocations is a limited preview."
    fields = {"Title": event["title"][:255], "EventName": name[:255],
              "EventID": event_id[:255], "Region": portfolio["key"][:255],
              "Count": count, "Threshold": threshold, "Status": status,
              "AlertReason": reason, "AffectedLocations": outcome.get("locations", ""),
              "Timestamp": timestamp, "AlertKey": record_key(event, portfolio, event_id)}
    record = {"event_key": event["key"], "source_url": event["url"],
              "portfolio_key": portfolio["key"], "portfolio_url": portfolio["url"],
              "event_id": event_id, "event_name": name, "active_breach": active,
              "fields": fields,
              "last_good_count": previous.get("last_good_count"),
              "last_good_fingerprint": previous.get("last_good_fingerprint")}
    if status in ("BREACH", "ALL CLEAR", "CLEAN"):
        record["last_good_count"] = count
        record["last_good_fingerprint"] = outcome.get("fingerprint")
    return record


def failure(exc):
    # Only application-defined exceptions have messages safe for logs/SharePoint.
    if isinstance(exc, requests.exceptions.SSLError):
        return {"status": "ERROR", "error": "TLS validation failed during authentication; check the approved CA bundle"}
    if isinstance(exc, requests.exceptions.ProxyError):
        return {"status": "ERROR", "error": "Proxy connection failed during authentication"}
    if isinstance(exc, requests.exceptions.Timeout):
        return {"status": "TIMEOUT", "error": "Authentication connection/read timeout"}
    if isinstance(exc, requests.exceptions.ConnectionError):
        return {"status": "ERROR", "error": "Network/DNS connection failed during authentication"}
    return {"status": "TIMEOUT" if isinstance(exc, QueryTimeout) else "ERROR",
            "error": str(exc) if isinstance(exc, MonitorError) else
            f"Unexpected {type(exc).__name__}; investigate locally"}


def analyse(config, previous):
    results = []
    event_client = ArcGIS(config)
    thread_local = threading.local()
    portfolios = {p["key"]: p for p in config["portfolios"] if p.get("enabled", True)}

    def work(event, portfolio, item):
        if not hasattr(thread_local, "client"):
            thread_local.client = ArcGIS(config)
        try:
            outcome = intersect(thread_local.client, portfolio, item["polygons"], config)
        except Exception as exc:
            outcome = failure(exc)
        key = record_key(event, portfolio, item["id"])
        return result_record(event, portfolio, item["id"], item["name"], outcome,
                             previous.get(key, {}), config, stamp())

    with ThreadPoolExecutor(max_workers=config.get("max_workers", 8)) as pool:
        futures = []
        for event in config["events"]:
            if not event.get("enabled", True):
                continue
            selected = [portfolios[key] for key in event["portfolios"] if key in portfolios]
            error = None
            try:
                items = read_events(event_client, event)
            except Exception as exc:
                items, error = {}, failure(exc)
            for portfolio in selected:
                old = {key: rec for key, rec in previous.items()
                       if rec["source_url"] == event["url"] and rec["event_key"] == event["key"]
                       and rec["portfolio_url"] == portfolio["url"]
                       and rec["portfolio_key"] == portfolio["key"]}
                for item in items.values():
                    futures.append(pool.submit(work, event, portfolio, item))
                # A vanished event is not proof that its previous footprint is now safe.
                for key, rec in old.items():
                    if rec["event_id"] == "__SOURCE__" or rec["event_id"] in items:
                        continue
                    missing = error or {"status": "ERROR", "error":
                        "Event is absent from the selected feed/window; safety is unknown, not all-clear."}
                    results.append(result_record(event, portfolio, rec["event_id"], rec["event_name"],
                                                 missing, rec, config, stamp()))
                source_key = record_key(event, portfolio, "__SOURCE__")
                # A dedicated source-health row makes an empty or broken feed visible.
                health = error or {"count": 0, "locations": "", "fingerprint": "source-ok"}
                row = result_record(event, portfolio, "__SOURCE__", "[Source health]", health,
                                    previous.get(source_key, {}), config, stamp())
                if not error:
                    row["fields"]["AlertReason"] = (f"Source query succeeded; {len(items)} selected events. "
                                                   "This row is feed health, not an exposure result.")
                results.append(row)
        for future in as_completed(futures):
            results.append(future.result())
    return sorted(results, key=lambda rec: rec["fields"]["AlertKey"])


class SharePoint:
    def __init__(self, config):
        import msal
        self.config = config
        self.sp = config["sharepoint"]
        self.http = Http(config)
        tenant = required_env("M365_TENANT_ID")
        if not re.fullmatch(r"[A-Za-z0-9.-]+", tenant):
            raise MonitorError("Invalid M365_TENANT_ID")
        if os.environ.get("M365_CERT_PRIVATE_KEY_PATH"):
            credential = {"private_key": Path(required_env("M365_CERT_PRIVATE_KEY_PATH")).read_text(),
                          "thumbprint": required_env("M365_CERT_THUMBPRINT")}
            if os.environ.get("M365_CERT_PASSPHRASE"):
                credential["passphrase"] = os.environ["M365_CERT_PASSPHRASE"]
        else:
            credential = required_env("M365_CLIENT_SECRET")
        self.app = msal.ConfidentialClientApplication(
            required_env("M365_CLIENT_ID"), authority=f"https://login.microsoftonline.com/{tenant}",
            client_credential=credential, verify=self.http.verify,
            timeout=self.http.timeout)
        self.site = self.sp.get("site_id") or os.environ.get("M365_SITE_ID")
        self.list_id = self.sp.get("list_id") or os.environ.get("M365_LIST_ID")
        if not self.site or not self.list_id:
            raise MonitorError("Set M365_SITE_ID and M365_LIST_ID (or config IDs supplied by IT)")
        self.base = f"/sites/{quote(self.site, safe=',')}/lists/{quote(self.list_id, safe='')}"
        self.mapping = self.sp.get("field_map", {})

    def call(self, method, path, **kwargs):
        if path.startswith("https://"):
            if not path.startswith(GRAPH + "/"):
                raise MonitorError("Refused Graph pagination URL outside the Graph v1.0 endpoint")
            url = path
        else:
            url = GRAPH + path
        token = self.app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
        if "access_token" not in token:
            error = re.sub(r"[^A-Za-z0-9_.-]", "", str(token.get("error", "unknown")))[:80]
            correlation = re.sub(r"[^A-Za-z0-9-]", "", str(token.get("correlation_id", "")))[:80]
            raise MonitorError(f"Entra authentication failed: {error}; correlation-id={correlation}")
        return self.http.request(method, url, headers={"Authorization": "Bearer " + token["access_token"]},
                                 **kwargs)

    def pages(self, path, params=None):
        while path:
            reply = self.call("GET", path, params=params)
            if not isinstance(reply.get("value"), list):
                raise MonitorError("Graph collection response is missing value[]")
            yield from reply["value"]
            path, params = reply.get("@odata.nextLink"), None

    def check_schema(self):
        columns = list(self.pages(self.base + "/columns", params={"$select":
            "name,displayName,hidden,readOnly,required,indexed,enforceUniqueValues,text,number,choice,dateTime"}))
        by_name = {col["name"]: col for col in columns}
        mapped = {self.mapping.get(name, name) for name in FIELDS}
        for col in columns:
            if col.get("required") and not col.get("readOnly") and col["name"] not in mapped:
                raise MonitorError(f"Additional required SharePoint column needs a value: {col['name']}")
        LOG.info("SharePoint columns (internal name -> display name): %s",
                 {col["name"]: col.get("displayName") for col in columns})
        for logical in FIELDS:
            name = self.mapping.get(logical, logical)
            if name not in by_name:
                raise MonitorError(f"Missing SharePoint internal column: {name}; adjust field_map")
            col = by_name[name]
            if col.get("readOnly"):
                raise MonitorError(f"SharePoint column is read-only: {name}")
            if logical in ("Count", "Threshold") and "number" not in col:
                raise MonitorError(f"{name} must be a Number column")
            if logical == "Count" and col.get("required"):
                raise MonitorError("Count must allow blanks so ERROR/TIMEOUT cannot look like zero exposure")
            if logical == "Timestamp" and "dateTime" not in col:
                raise MonitorError(f"{name} must be a Date and Time column")
            if logical in ("Title", "EventName", "EventID", "Region", "AlertKey"):
                text_def = col.get("text")
                if text_def is None or text_def.get("allowMultipleLines"):
                    raise MonitorError(f"{name} must be a single-line text column")
                minimum = 64 if logical == "AlertKey" else 255
                if text_def.get("maxLength") and text_def["maxLength"] < minimum:
                    raise MonitorError(f"{name} must allow at least {minimum} characters")
            if logical == "Status" and not STATUSES.issubset(set(col.get("choice", {}).get("choices", []))):
                raise MonitorError(f"{name} must contain all six required status choices")
            if logical in ("AlertReason", "AffectedLocations"):
                text_def = col.get("text", {})
                if not text_def.get("allowMultipleLines") or text_def.get("textType") == "richText":
                    raise MonitorError(f"{name} must be a plain-text multiple-lines column")
            if logical == "AlertKey" and not (col.get("indexed") and col.get("enforceUniqueValues")
                                               and "text" in col and not col["text"].get("allowMultipleLines")):
                raise MonitorError("AlertKey must be indexed single-line Text with unique values enforced")
        LOG.info("SharePoint authentication, list read and schema checks passed (no test write performed)")

    def upsert(self, fields):
        key_field = self.mapping.get("AlertKey", "AlertKey")
        key = fields["AlertKey"]
        matches = list(self.pages(self.base + "/items", params={
            "$filter": f"fields/{key_field} eq '{key}'", "$select": "id", "$top": "2"}))
        if len(matches) > 1:
            raise MonitorError("Duplicate AlertKey rows exist; repair the list before continuing")
        payload = {self.mapping.get(name, name): value for name, value in fields.items()}
        if matches:
            self.call("PATCH", self.base + f"/items/{quote(matches[0]['id'], safe='')}/fields", json=payload)
        else:
            # POST is not blindly retried: an ambiguous failure stays in the durable outbox.
            self.call("POST", self.base + "/items", json={"fields": payload}, retryable=False)


def enqueue(state, records):
    for record in records:
        key = record["fields"]["AlertKey"]
        state["records"][key] = record
        state["outbox"].append(copy.deepcopy(record["fields"]))


def flush_outbox(state, path, sink, maximum=1000):
    sent = 0
    while state["outbox"] and sent < maximum:
        sink.upsert(state["outbox"][0])
        state["outbox"].pop(0)
        # If a crash occurs between remote success and this save, the key makes replay an update.
        atomic_json(path, state)
        sent += 1
    return sent


def validate_config(config):
    if not 1 <= config.get("max_workers", 8) <= 32:
        raise MonitorError("max_workers must be between 1 and 32")
    if config.get("affected_location_limit", 100) < 0:
        raise MonitorError("affected_location_limit must be nonnegative")
    for group in ("portfolios", "events"):
        keys = [item["key"] for item in config[group]]
        if len(keys) != len(set(keys)):
            raise MonitorError(f"Duplicate keys in {group}")
        for item in config[group]:
            https_url(item["url"])
    portfolio_keys = {item["key"] for item in config["portfolios"]}
    for event in config["events"]:
        if not set(event["portfolios"]).issubset(portfolio_keys):
            raise MonitorError("An event refers to an unknown portfolio key")
    for portfolio in config["portfolios"]:
        threshold = portfolio.get("threshold", config.get("global_threshold", 1))
        if not isinstance(threshold, int) or threshold < 1:
            raise MonitorError("Thresholds must be positive integers")
    for field in config["sharepoint"].get("field_map", {}).values():
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", field):
            raise MonitorError("Unexpected SharePoint internal field name in field_map")
    mapped = [config["sharepoint"].get("field_map", {}).get(name, name) for name in FIELDS]
    if len(set(mapped)) != len(FIELDS):
        raise MonitorError("Each logical SharePoint field must map to a different column")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config.json")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true", help="Analyse only; no SharePoint/state writes")
    mode.add_argument("--check-arcgis", action="store_true", help="Read metadata only, no analysis or writes")
    mode.add_argument("--check-sharepoint", action="store_true", help="Authenticate/read schema, no writes")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        config_path = Path(args.config).resolve()
        config = json.loads(config_path.read_text(encoding="utf-8"))
        validate_config(config)
        if args.check_sharepoint:
            SharePoint(config).check_schema()
            return 0
        if args.check_arcgis:
            client = ArcGIS(config)
            failed = False
            for group, geometry in (("events", "esriGeometryPolygon"), ("portfolios", "esriGeometryPoint")):
                for layer in config[group]:
                    if layer.get("enabled", True):
                        try:
                            meta = client.meta(layer, geometry)
                            LOG.info("ArcGIS %s: OK; service layer name=%s", layer["key"], meta.get("name"))
                        except Exception as exc:
                            failed = True
                            LOG.error("ArcGIS %s: %s", layer["key"], failure(exc)["error"])
            return 2 if failed else 0
        runtime = (config_path.parent / config.get("runtime_directory", "runtime")).resolve()
        runtime.mkdir(parents=True, exist_ok=True)
        with FileLock(str(runtime / "nebula.lock"), timeout=0):
            state_path = runtime / "nebula_state.json"
            state = load_state(state_path)
            if not args.dry_run and len(state["outbox"]) >= config.get("max_outbox_records", 10000):
                sink = SharePoint(config)
                sink.check_schema()
                flush_outbox(state, state_path, sink, len(state["outbox"]))
            records = analyse(config, state["records"])
            atomic_json(runtime / ("dry_run_results.json" if args.dry_run else "latest_results.json"),
                        {"checked_at": stamp(), "results": [r["fields"] for r in records]})
            statuses = {s: sum(r["fields"]["Status"] == s for r in records) for s in sorted(STATUSES)}
            LOG.info("Results including source-health rows: %s", statuses)
            if args.dry_run:
                LOG.info("Dry run complete; SharePoint and durable state were not changed")
            else:
                enqueue(state, records)
                atomic_json(state_path, state)  # persist observations AND pending writes together
                sink = SharePoint(config)
                sink.check_schema()
                sent = flush_outbox(state, state_path, sink, config.get("max_deliveries_per_run", 1000))
                LOG.info("Delivered %s updates; %s queued", sent, len(state["outbox"]))
                if state["outbox"]:
                    return 3
            return 2 if any(r["fields"]["Status"] in {"ERROR", "TIMEOUT", "SUSPECT"} for r in records) else 0
    except LockTimeout:
        LOG.error("Another run holds the local runtime lock; skipped")
        return 4
    except Exception as exc:
        LOG.error("Run failed: %s", failure(exc)["error"])
        return 1


if __name__ == "__main__":
    sys.exit(main())
