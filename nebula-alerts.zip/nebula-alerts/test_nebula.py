"""Offline behavioural tests; no company, ArcGIS or Microsoft endpoints contacted."""
import copy
import json
import os
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import nebula_monitor as n


def config():
    return json.loads(Path(__file__).with_name("config.example.json").read_text())


class StateTests(unittest.TestCase):
    def setUp(self):
        self.c = config()
        self.e = self.c["events"][0]
        self.p = self.c["portfolios"][0]

    def result(self, count=1, previous=None, **kwargs):
        outcome = {"count": count, "locations": "Location A", "fingerprint": str(count), **kwargs}
        return n.result_record(self.e, self.p, "storm1", "Storm One", outcome,
                               previous or {}, self.c, "2026-10-16T12:00:00Z")

    def test_breach_count_change_and_clear(self):
        first = self.result(1)
        changed = self.result(3, first)
        cleared = self.result(0, changed)
        self.assertEqual(first["fields"]["Status"], "BREACH")
        self.assertIn("changed from 1 to 3", changed["fields"]["AlertReason"])
        self.assertEqual(cleared["fields"]["Status"], "ALL CLEAR")
        self.assertFalse(cleared["active_breach"])
        self.assertEqual(self.result(0, cleared)["fields"]["Status"], "ALL CLEAR")

    def test_failed_query_preserves_last_confirmed_breach(self):
        first = self.result(4)
        failed = self.result(None, first, error="Network problem", status="ERROR")
        self.assertTrue(failed["active_breach"])
        self.assertIsNone(failed["fields"]["Count"])
        self.assertEqual(failed["last_good_count"], 4)
        self.assertEqual(self.result(0, failed)["fields"]["Status"], "ALL CLEAR")

    def test_suspect_count_does_not_resolve_previous_breach(self):
        first = self.result(4)
        suspect = self.result(15001, first)
        self.assertEqual(suspect["fields"]["Status"], "SUSPECT")
        self.assertTrue(suspect["active_breach"])
        self.assertEqual(suspect["last_good_count"], 4)

    def test_same_count_different_locations_is_detected(self):
        first = self.result(4)
        changed = self.result(4, first, fingerprint="different")
        self.assertIn("features changed", changed["fields"]["AlertReason"])

    def test_region_threshold_and_nonzero_all_clear(self):
        self.p["threshold"] = 5
        self.assertEqual(self.result(4)["fields"]["Status"], "CLEAN")
        first = self.result(5)
        self.assertEqual(self.result(4, first)["fields"]["Status"], "ALL CLEAR")

    def test_timeout_not_clean(self):
        row = n.result_record(self.e, self.p, "storm1", "One", n.failure(n.QueryTimeout("Timed out")),
                              {}, self.c, n.stamp())
        self.assertEqual(row["fields"]["Status"], "TIMEOUT")
        self.assertIsNone(row["fields"]["Count"])

    def test_missing_event_is_unknown_not_resolved(self):
        previous = self.result(3)
        with patch.object(n, "read_events", return_value={}):
            rows = n.analyse(self.c, {previous["fields"]["AlertKey"]: previous})
        old = next(r for r in rows if r["event_id"] == "storm1")
        self.assertEqual(old["fields"]["Status"], "ERROR")
        self.assertTrue(old["active_breach"])

    def test_broken_event_feed_marks_existing_rows_unknown(self):
        previous = self.result(3)
        with patch.object(n, "read_events", side_effect=n.QueryTimeout("Test timeout")):
            rows = n.analyse(self.c, {previous["fields"]["AlertKey"]: previous})
        self.assertTrue(all(r["fields"]["Status"] == "TIMEOUT" for r in rows))


class SpatialTests(unittest.TestCase):
    def test_overlapping_polygons_do_not_double_count(self):
        c = config()
        p = c["portfolios"][0]
        client = MagicMock()
        client.meta.return_value = {"objectIdField": "OBJECTID"}
        client.ids.side_effect = [{1, 2}, {2, 3}]
        client.features.return_value = [{"attributes": {"OBJECTID": i, "Locid": str(i),
                                                        "AccountName": f"A{i}"}} for i in (1, 2, 3)]
        result = n.intersect(client, p, [{"rings": [1]}, {"rings": [2]}], c)
        self.assertEqual(result["count"], 3)
        self.assertEqual(client.features.call_args.args[1], [1, 2, 3])
        self.assertEqual(client.ids.call_args.kwargs["spatialRel"], "esriSpatialRelIntersects")

    def test_id_cap_or_mid_query_change_is_an_error(self):
        client = n.ArcGIS(config())
        client.call = MagicMock(side_effect=[{"objectIds": [1, 2]}, {"count": 3}])
        with self.assertRaisesRegex(n.MonitorError, "ID/count mismatch"):
            client.ids({"url": "https://example.test/layer"})

    def test_feature_paging_and_incomplete_batch(self):
        client = n.ArcGIS(config())
        layer = {"url": "https://example.test/FeatureServer/0"}
        client.metadata[layer["url"]] = {"objectIdField": "OID", "maxRecordCount": 2}
        client.call = MagicMock(side_effect=[
            {"features": [{"attributes": {"OID": 1}}, {"attributes": {"OID": 2}}]},
            {"features": [{"attributes": {"OID": 3}}]}])
        self.assertEqual(len(client.features(layer, {1, 2, 3}, ["OID"])), 3)
        client.call = MagicMock(return_value={"features": []})
        with self.assertRaisesRegex(n.MonitorError, "Incomplete feature batch"):
            client.features(layer, {1}, ["OID"])

    def test_polygon_spatial_reference_is_checked(self):
        client = n.ArcGIS(config())
        layer = {"url": "https://example.test/FeatureServer/0"}
        client.metadata[layer["url"]] = {"objectIdField": "OID"}
        client.call = MagicMock(return_value={"spatialReference": {"wkid": 3857}, "features": [
            {"attributes": {"OID": 1}, "geometry": {"rings": [[[0, 0], [1, 1], [0, 0]]]}}]})
        with self.assertRaisesRegex(n.MonitorError, "EPSG:4326"):
            client.features(layer, {1}, ["OID"], True)

    def test_preview_limit_does_not_limit_count(self):
        c = config()
        c["affected_location_limit"] = 1
        client = MagicMock()
        client.meta.return_value = {"objectIdField": "OBJECTID"}
        client.ids.return_value = {1, 2, 3}
        client.features.return_value = [{"attributes": {"OBJECTID": 1, "Locid": "L1", "AccountName": "A"}}]
        result = n.intersect(client, c["portfolios"][0], [{"rings": [1]}], c)
        self.assertEqual(result["count"], 3)
        self.assertTrue(result["truncated"])

    def test_rolling_window_uses_fixed_utc_literal(self):
        c = config()
        where = n.event_where(c["events"][0], datetime(2026, 10, 16, 12, tzinfo=timezone.utc))
        self.assertIn("ENDDTG >= TIMESTAMP '2026-10-13 12:00:00'", where)

    def test_one_storm_with_multiple_polygons_is_grouped(self):
        e = config()["events"][0]
        client = MagicMock()
        client.meta.return_value = {"name": "Observed swath"}
        client.ids.return_value = {1, 2}
        client.features.return_value = [
            {"attributes": {"STORMID": "A", "STORMNAME": "One"}, "geometry": {"rings": [i]}}
            for i in (1, 2)]
        result = n.read_events(client, e)
        self.assertEqual(len(result), 1)
        self.assertEqual(len(result["A"]["polygons"]), 2)


class DeliveryTests(unittest.TestCase):
    def schema_sink(self):
        sink = n.SharePoint.__new__(n.SharePoint)
        sink.mapping, sink.base = {}, "/sites/S/lists/L"
        columns = []
        for name in n.FIELDS:
            column = {"name": name, "displayName": name, "text": {"maxLength": 255}}
            if name in ("Count", "Threshold"):
                column.pop("text")
                column["number"] = {}
            elif name == "Timestamp":
                column.pop("text")
                column["dateTime"] = {}
            elif name == "Status":
                column.pop("text")
                column["choice"] = {"choices": list(n.STATUSES)}
            elif name in ("AlertReason", "AffectedLocations"):
                column["text"] = {"allowMultipleLines": True, "textType": "plain"}
            elif name == "AlertKey":
                column.update(indexed=True, enforceUniqueValues=True)
            columns.append(column)
        sink.pages = MagicMock(return_value=columns)
        return sink, columns

    def test_required_schema_accepts_valid_columns(self):
        sink, _ = self.schema_sink()
        sink.check_schema()

    def test_schema_requires_unique_alert_key(self):
        sink, columns = self.schema_sink()
        next(c for c in columns if c["name"] == "AlertKey")["enforceUniqueValues"] = False
        with self.assertRaisesRegex(n.MonitorError, "unique values"):
            sink.check_schema()

    def test_schema_rejects_required_count(self):
        sink, columns = self.schema_sink()
        next(c for c in columns if c["name"] == "Count")["required"] = True
        with self.assertRaisesRegex(n.MonitorError, "allow blanks"):
            sink.check_schema()

    def test_failed_write_remains_durable_and_ordered(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "state.json"
            state = {"version": 1, "records": {}, "outbox": [{"Status": "BREACH"}, {"Status": "ALL CLEAR"}]}
            n.atomic_json(path, state)
            sink = MagicMock()
            sink.upsert.side_effect = n.MonitorError("Denied")
            with self.assertRaises(n.MonitorError):
                n.flush_outbox(state, path, sink)
            self.assertEqual(len(n.load_state(path)["outbox"]), 2)
            sink.upsert.side_effect = None
            self.assertEqual(n.flush_outbox(state, path, sink), 2)
            self.assertEqual(n.load_state(path)["outbox"], [])

    def test_graph_existing_key_updates_and_new_key_creates(self):
        sink = n.SharePoint.__new__(n.SharePoint)
        sink.mapping, sink.base = {}, "/sites/S/lists/L"
        sink.pages = MagicMock(return_value=iter([{"id": "11"}]))
        sink.call = MagicMock()
        sink.upsert({"AlertKey": "abc", "Status": "BREACH"})
        self.assertEqual(sink.call.call_args.args, ("PATCH", "/sites/S/lists/L/items/11/fields"))
        sink.pages = MagicMock(return_value=iter([]))
        sink.upsert({"AlertKey": "abc", "Status": "BREACH"})
        self.assertEqual(sink.call.call_args.args[0], "POST")
        self.assertFalse(sink.call.call_args.kwargs["retryable"])

    def test_ambiguous_remote_success_is_replayed_as_update(self):
        sink = n.SharePoint.__new__(n.SharePoint)
        sink.mapping, sink.base = {}, "/sites/S/lists/L"
        remote, calls = {}, []
        sink.pages = lambda *a, **k: iter([{"id": "1"}] if remote else [])
        def transport(method, path, **kwargs):
            calls.append(method)
            if method == "POST":
                remote.update(kwargs["json"]["fields"])
                raise n.QueryTimeout("Response lost after commit")
            remote.update(kwargs["json"])
        sink.call = transport
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "state.json"
            state = {"version": 1, "records": {}, "outbox": [{"AlertKey": "key", "Status": "BREACH"}]}
            n.atomic_json(path, state)
            with self.assertRaises(n.QueryTimeout):
                n.flush_outbox(state, path, sink)
            self.assertEqual(len(state["outbox"]), 1)
            n.flush_outbox(state, path, sink)
        self.assertEqual(calls, ["POST", "PATCH"])

    def test_dry_run_does_not_advance_state_or_contact_sharepoint(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "config.json"
            c = config()
            path.write_text(json.dumps(c))
            state_path = Path(folder) / "runtime" / "nebula_state.json"
            original = {"version": 1, "records": {}, "outbox": []}
            n.atomic_json(state_path, original)
            before = state_path.read_bytes()
            with patch.object(n, "analyse", return_value=[]), patch.object(n, "SharePoint") as sink:
                self.assertEqual(n.main(["--config", str(path), "--dry-run"]), 0)
                sink.assert_not_called()
            self.assertEqual(state_path.read_bytes(), before)

    def test_corrupt_state_does_not_silently_reset(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "state.json"
            path.write_text("not JSON")
            with self.assertRaises(n.MonitorError):
                n.load_state(path)


class AuthenticationTests(unittest.TestCase):
    def test_public_arcgis_call_has_no_portal_token(self):
        client = n.ArcGIS(config())
        client.token = MagicMock()
        client.http.request = MagicMock(return_value={"ok": True})
        client.call(config()["events"][0])
        client.token.assert_not_called()
        self.assertNotIn("token", client.http.request.call_args.kwargs["data"])

    def test_unapproved_server_cannot_receive_token(self):
        client = n.ArcGIS(config())
        with self.assertRaisesRegex(n.MonitorError, "outside allowed"):
            client.token("https://unapproved.example.test/server")

    def test_password_whitespace_is_not_modified(self):
        with patch.dict(os.environ, {"ARCGIS_PASSWORD": "  synthetic-value  "}):
            self.assertEqual(n.required_env("ARCGIS_PASSWORD"), "  synthetic-value  ")

    def test_http_forbidden_error_does_not_expose_response_body(self):
        http = n.Http(config())
        response = MagicMock(status_code=403, headers={})
        response.json.return_value = {"error": {"code": "accessDenied", "message": "PRIVATE RESPONSE"}}
        http.session.request = MagicMock(return_value=response)
        with self.assertRaises(n.HttpFailure) as raised:
            http.request("GET", "https://graph.microsoft.com/v1.0/test")
        self.assertIn("accessDenied", str(raised.exception))
        self.assertNotIn("PRIVATE RESPONSE", str(raised.exception))


if __name__ == "__main__":
    unittest.main()
