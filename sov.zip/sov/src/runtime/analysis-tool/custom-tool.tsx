/* eslint-disable new-cap */
/** @jsx jsx */
import { loadArcGISJSAPIModules } from 'jimu-arcgis'
import {
  React, jsx, type ImmutableObject, hooks, lodash, requestUtils, loadArcGISJSAPIModule, defaultMessages as jimCoreDefaultMessages, css, UtilityManager, ReactRedux, type IMState, esri, SessionManager, portalUrlUtils
} from 'jimu-core'
import { type CustomToolConfig } from '../../config'
import { Alert, Loading, defaultMessages as jimuiDefaultMessages } from 'jimu-ui'
import { type AnalysisToolDataItem, type AnalysisToolData, AnalysisEngine, AnalysisType, type AnalysisToolParam, type LocaleItem, type AnalysisServiceInfo } from 'analysis-ui-schema'
import defaultMessages from '../translations/default'
import { calculateParameterValues, CLIENT_THROWN_ERROR, getJobParams, getResultParams, getUIOnlyParams, isEmptyDataItem, type SupportedLayer, hasNAPrivilege, type AnalysisGPJobStatus, getAnalysisLayers } from 'analysis-shared-utils'
// @ts-expect-error
import { type AnalysisToolDataChangeEventDetail, showHelp } from 'analysis-components'
import { CalciteFlowItem, CalciteAction, CalciteNotice, CalciteButton } from 'calcite-components'
import { type ToolProps } from './config'
import { useCommonStrings, useErrorMessageStrings, useGPMessageStrings } from '../../utils/strings'
import { executeJob } from '../../utils/job'
import { type AnalysisToolAppContainerCustomEvent } from 'analysis-tool-app'
import { AnalysisCoreEvents, notifyJobSubmited } from '../../utils/events'
import { getCustomToolUrlWithToken, useGetDisplayedToolName, useUpdateObjectByStateEffect } from '../../utils/util'
import { convertInputGPValueParameters, convertJobParamsToToolData, getDefaultToolUIJson, useAnalysisMapLayersFromMap } from '../utils'

enum ValidityState {
  Valid = 'VALID',
  Warning = 'WARNING',
  Error = 'ERROR'
}

const alertStyle = css`
  position: absolute;
  left: 4px;
  right: 4px;
  bottom: 4px;
  width: auto !important;
  z-index: 1;
`

const { useState, useMemo, useEffect, useRef, useCallback } = React

// ✅ CUSTOM: Helper to inject a hide style into a given ShadowRoot
// We tag the injected style with data-custom-hide to avoid duplicate injections
const injectHideStyleIntoShadowRoot = (shadowRoot: ShadowRoot): void => {
  if (shadowRoot.querySelector('style[data-custom-hide]')) {
    return // Already injected, skip
  }
  const style = document.createElement('style')
  style.setAttribute('data-custom-hide', 'true')
  // Hide the primary-button (Add Data) inside analysis-item-input shadow roots
  style.textContent = `
    .primary-button {
      display: none !important;
    }
    .analysis-item-input-buttons-container .primary-button {
      display: none !important;
    }
  `
  shadowRoot.appendChild(style)
}

// ✅ CUSTOM: Process a single Element node —
// if it is (or contains) an analysis-item-input, inject the hide style
const processNodeForAddDataHide = (node: Element): void => {
  // Handle the node itself
  if (node.tagName?.toLowerCase() === 'analysis-item-input') {
    if (node.shadowRoot) {
      injectHideStyleIntoShadowRoot(node.shadowRoot)
    }
  }
  // Handle any analysis-item-input descendants
  node.querySelectorAll?.('analysis-item-input').forEach((el) => {
    if (el.shadowRoot) {
      injectHideStyleIntoShadowRoot(el.shadowRoot)
    }
  })
}

// ✅ CUSTOM: Set up a MutationObserver on the given root element.
// Watches for any analysis-item-input components being added to the subtree
// and injects the hide style into their shadow roots.
// Returns the observer so the caller can disconnect it on unmount.
const observeAndHideAddDataButton = (rootElement: HTMLElement): MutationObserver => {
  // Run an initial pass in case elements are already in the DOM
  processNodeForAddDataHide(rootElement)

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
        if (node instanceof Element) {
          processNodeForAddDataHide(node)
        }
      })
    })
  })

  observer.observe(rootElement, {
    childList: true,
    subtree: true
  })

  return observer
}

const CustomTool = (props: ToolProps) => {
  const { theme, appContainer, jimuMapView, portal, jobParams, toolInfo, disableBack, onBack } = props

  const { toolName, id: toolId, config: toolConfig } = toolInfo

  const { toolInfo: toolJson, toolUrl, option, utility } = toolConfig as ImmutableObject<CustomToolConfig>

  const webToolServerUrl = useMemo(() => toolUrl.slice(0, toolUrl.lastIndexOf('/')), [toolUrl])

  const getDisplayedToolName = useGetDisplayedToolName()

  const displayedToolName = useMemo(() => getDisplayedToolName(toolInfo), [getDisplayedToolName, toolInfo])

  const mutableToolJson = useMemo(() => toolJson.asMutable({ deep: true }), [toolJson])

  const translate = hooks.useTranslation(defaultMessages, jimuiDefaultMessages, jimCoreDefaultMessages)

  const [geoprocessor, setGeoprocessor] = useState<__esri.geoprocessor>()
  useEffect(() => {
    loadArcGISJSAPIModules(['esri/rest/geoprocessor']).then((modules) => {
      const gp = modules[0] as __esri.geoprocessor
      setGeoprocessor(gp)
    })
  }, [])

  const map = useMemo(() => {
    return jimuMapView?.view?.map
  }, [jimuMapView])

  const [analysisToolContainer, setAnalysisToolContainer] = useState<HTMLAnalysisToolElement>(null)

  const [analysisToolAppLoaded, setAnalysisToolAppLoaded] = useState(false)
  const [analysisToolData, setAnalysisToolData] = useState<CustomEvent<AnalysisToolDataChangeEventDetail>>()

  const [allLayers, setAllLayers] = useState<SupportedLayer[]>([])

  const [defaultJobParams, setDefaultJobParams] = useState<AnalysisToolData>()

  const realJobParams = useMemo(() => jobParams || defaultJobParams, [defaultJobParams, jobParams])

  const analysisToolContainerRef = useRef<HTMLDivElement>(null)

  // ✅ CUSTOM: Ref to hold the MutationObserver instance so we can
  // disconnect it when the component unmounts or the tool is recreated
  const addDataObserverRef = useRef<MutationObserver>(null)

  const setAnalysisToolRef = (ref: HTMLDivElement, recreate: boolean = false) => {
    analysisToolContainerRef.current = ref
    if ((analysisToolContainer && !recreate) || !ref) {
      return
    }

    const container = document.createElement('analysis-tool') as any
    container.isHelpFileExternalAsset = true
    container.usePanel = false
    container.closable = false
    ref.appendChild(container)
    setAnalysisToolContainer(container)

    // ✅ CUSTOM: Disconnect any existing observer before starting a new one
    // (important when recreate = true, i.e. tool type changed)
    if (addDataObserverRef.current) {
      addDataObserverRef.current.disconnect()
    }

    // ✅ CUSTOM: Start observing the container div (not the web component itself)
    // so we catch all analysis-item-input elements as they are rendered
    addDataObserverRef.current = observeAndHideAddDataButton(ref)
  }

  const changeContainerParamsUpdated = () => {}

  const mapLayers = useAnalysisMapLayersFromMap(map)
  const [analysisLayers, setAnalysisLayers] = useState<SupportedLayer[]>()
  const commonStrings = useCommonStrings()

  const [convertedParameters, setConvertedParameters] = useState<AnalysisToolParam[]>([])

  const utilityJson = ReactRedux.useSelector((state: IMState) => {
    const s = state.appStateInBuilder ?? state
    return s.appConfig.utilities?.[utility?.utilityId]
  })

  const [serviceInfo, setServiceInfo] = useState<AnalysisServiceInfo>()
  const getServiceInfo = () => {
    const getUtilityServiceInfo = async (): Promise<AnalysisServiceInfo> => {
      if (utilityJson?.portalUrl && utilityJson?.itemId) {
        const { itemId, portalUrl } = utilityJson

        await esri.restPortal.getItem(itemId, {
          portal: portalUrlUtils.getPortalRestUrl(portalUrl),
          authentication: SessionManager.getInstance().getSessionByUrl(portalUrl)
        })
      }
      return UtilityManager.getServiceInfo(webToolServerUrl)
    }

    return getUtilityServiceInfo().then((res) => {
      setServiceInfo(res)
      reportUtilityState(true)
      return res
    }).catch((error) => {
      console.log('Get server info error', error)
      checkErrorAndReportUtilityState(error)
      return Promise.reject(error)
    })
  }

  useEffect(() => {
    setRunAnalysisDisabled(true)
    getServiceInfo().finally(() => {
      setRunAnalysisDisabled(false)
    })
  }, [])

  const convertedToolJson = useMemo(() => {
    const parameters = convertedParameters?.length ? convertedParameters : mutableToolJson.parameters
    return {
      ...mutableToolJson,
      serviceInfo,
      parameters: convertInputGPValueParameters(parameters, jimuMapView?.view as __esri.MapView, allLayers, portal?.user)
    }
  }, [allLayers, convertedParameters, jimuMapView?.view, mutableToolJson, portal?.user, serviceInfo])

  const supportsUpload = useMemo(() => !!convertedToolJson?.serviceInfo?.capabilities?.includes?.('Uploads'), [convertedToolJson?.serviceInfo])

  const toolUIJson = useMemo(() => getDefaultToolUIJson(convertedToolJson, translate, portal, commonStrings), [commonStrings, convertedToolJson, portal, translate])

  useUpdateObjectByStateEffect(analysisToolContainer, portal, 'portal')
  useUpdateObjectByStateEffect(analysisToolContainer, portal?.user, 'user')
  useUpdateObjectByStateEffect(analysisToolContainer, jimuMapView?.view, 'mapView')
  useUpdateObjectByStateEffect(analysisToolContainer, toolJson?.helpUrl, 'toolHelpFilePath')
  useUpdateObjectByStateEffect(analysisToolContainer, convertedToolJson, 'toolJson', changeContainerParamsUpdated)
  useUpdateObjectByStateEffect(analysisToolContainer, toolUIJson, 'toolUIJson')
  useUpdateObjectByStateEffect(analysisToolContainer, supportsUpload, 'supportsUpload')
  useUpdateObjectByStateEffect(analysisToolContainer, webToolServerUrl, 'serviceUrl')

  useEffect(() => {
    if (!mapLayers) {
      return
    }
    if (mapLayers.length) {
      getAnalysisLayers(mapLayers, commonStrings as { [key: string]: LocaleItem }).then((layers) => {
        setAnalysisLayers(layers)
      }).catch(() => {
        setAnalysisLayers([])
      })
    } else {
      setAnalysisLayers([])
    }
  }, [mapLayers])

  useEffect(() => {
    if (!analysisToolContainer || !analysisLayers) {
      return
    }
    let allLayers = analysisLayers
    let selectedLayers = [] as SupportedLayer[]

    if (realJobParams) {
      convertJobParamsToToolData({
        jobParams: realJobParams,
        uiOnlyParams: {},
        toolJSON: mutableToolJson,
        availableMapLayers: analysisLayers,
        toolName
      }).then((jobParamsAndLayers) => {
        const toolDataFromHistory = jobParamsAndLayers.convertedJobParams
        const { valueTableSelectedLayersConvertedParameters, valueTableSelectedLayers, layers } = jobParamsAndLayers
        setConvertedParameters(valueTableSelectedLayersConvertedParameters)
        selectedLayers = [...layers, ...valueTableSelectedLayers]

        const toolData = {
          ...(toolDataFromHistory as AnalysisToolData),
          ...{
            userSettings: {
              unitSystem: portal.user?.units,
              hasNAPrivilege: hasNAPrivilege(portal.user)
            }
          }
        }

        allLayers = [...(analysisLayers ?? []), ...selectedLayers]
        setAllLayers(allLayers)
        analysisToolContainer.mapLayers = allLayers
        analysisToolContainer.toolData = toolData
        changeContainerParamsUpdated()
      })
    }
  }, [realJobParams, analysisLayers, analysisToolContainer])

  const [paramHelpPopover, setParamHelpPopover] = useState<HTMLAnalysisHelpPopoverElement>()

  useEffect(() => {
    if (analysisToolContainer) {
      analysisToolContainer.addEventListener('analysisToolLoaded', () => {
        setAnalysisToolAppLoaded(true)

        // ✅ CUSTOM: Run an extra pass once the tool has fully loaded,
        // catching any analysis-item-input elements that rendered after
        // the initial MutationObserver pass
        if (analysisToolContainerRef.current) {
          processNodeForAddDataHide(analysisToolContainerRef.current)
        }
      })
      analysisToolContainer.addEventListener('analysisToolDataChange', (e: CustomEvent<AnalysisToolDataChangeEventDetail>) => {
        setAnalysisToolData(e)
      })
      analysisToolContainer.addEventListener('analysisToolHelpPopoverChange', (e: CustomEvent<any>) => {
        setParamHelpPopover((e.target as HTMLAnalysisToolElement).toolHelpPopover)
      })
    }
  }, [analysisToolContainer])

  const getColoredDesc = (desc: string) => {
    return `<span style="color: ${theme?.colors?.palette?.dark?.[500]}">${desc}</span>`
  }

  useEffect(() => {
    if (!paramHelpPopover) {
      return
    }
    const paramName = paramHelpPopover.helpId
    const paramInfo = toolJson.parameters?.find((p) => p.name === paramName)
    if (paramInfo) {
      paramHelpPopover.helpSrcdoc = getColoredDesc(paramInfo.description)
    }
  }, [paramHelpPopover])

  useEffect(() => {
    if (!analysisToolContainer) {
      return
    }
const containerParent = analysisToolContainer.parentElement as HTMLDivElement
    containerParent.removeChild(analysisToolContainer)
    setAnalysisToolRef(containerParent, true)
  }, [toolId])

  // ✅ CUSTOM: Disconnect the MutationObserver when the component unmounts
  // to avoid memory leaks
  useEffect(() => {
    return () => {
      if (addDataObserverRef.current) {
        addDataObserverRef.current.disconnect()
        addDataObserverRef.current = null
      }
    }
  }, [])

  const errorStrings = useErrorMessageStrings()
  const gpMessages = useGPMessageStrings()

  const headerElementRef = useRef<HTMLDivElement>()
  const toolHelpPopover = useRef<HTMLAnalysisHelpPopoverElement>()

  const [validationStatus, setValidationStatus] = useState<ValidityState>()
  const [errorMessage, setErrorMessage] = useState<string | string[]>()

  const panelElementRef = useRef<HTMLCalciteFlowItemElement>()

  const parameters = useRef<{ currentJobParams: AnalysisToolData, toolUiParameters?: AnalysisToolData }>()

  // eslint-disable-next-line @typescript-eslint/consistent-indexed-object-style
  const onToolDataChange = (e?: CustomEvent<AnalysisToolDataChangeEventDetail> | Record<'detail', AnalysisToolDataChangeEventDetail>) => {
    const { toolData } = e?.detail ?? {}
    const jobParams = getJobParams(convertedToolJson, toolData)
    const calculatedJobParams = calculateParameterValues(jobParams as AnalysisToolData)
    const currentJobParams = { ...calculatedJobParams }
    const recalculatedToolUiParams = getUIOnlyParams({
      toolData: toolData,
      keysToRemove: Object.keys(currentJobParams),
      isWebTool: true
    })
    let toolUiParameters
    if (!isEmptyDataItem(recalculatedToolUiParams)) {
      toolUiParameters = recalculatedToolUiParams
    }
    parameters.current = {
      currentJobParams,
      toolUiParameters
    }

    if (!defaultJobParams) {
      setDefaultJobParams(currentJobParams)
    }
  }

  const [runAnalysisDisabled, setRunAnalysisDisabled] = useState(false)
  const runAnalysysDisabledRef = useRef(runAnalysisDisabled)
  useEffect(() => {
    runAnalysysDisabledRef.current = runAnalysisDisabled
  }, [runAnalysisDisabled])

  const utilityState = ReactRedux.useSelector((state: IMState) => {
    const s = state.appStateInBuilder ?? state
    return s.appRuntimeInfo?.utilityStates?.[utility?.utilityId]
  })

  const [utilityErrorMessage, setUtilityErrorMessage] = useState('')
  const [, setUtilityErrorAlertTimer] = useState<NodeJS.Timeout>()
  React.useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-boolean-literal-compare
    if (utilityState?.success === false) {
      setUtilityErrorMessage(utilityState.isSignInError ? 'signInErrorDefault' : 'utilityNotAvailable')

      const timer = setTimeout(() => {
        setUtilityErrorAlertTimer((t) => {
          if (t === timer) {
            setUtilityErrorMessage('')
            return null
          }
          return t
        })
      }, 5000)
      setUtilityErrorAlertTimer(timer)
    }
  }, [utilityState])

  const reportUtilityState = (state: boolean, isSignInError?: boolean) => {
    const utilityId = utility?.utilityId
    if (utilityId) {
      UtilityManager.getInstance().reportUtilityState(utilityId, state, isSignInError)
    }
  }

  const checkErrorAndReportUtilityState = (error: any) => {
    const isSignInError = UtilityManager.getInstance().utilityHasSignInError(utility?.utilityId)
    const utilityNotFound = [400, 404].includes(error?.details?.httpStatus || error?.response?.error?.code)
    reportUtilityState(!(isSignInError || utilityNotFound), isSignInError)
  }

  const esriRequestRef = useRef<typeof __esri.request>()

  const handleJobSubmitedError = () => {
    requestUtils.requestWrapper(toolUrl, async (session) => {
      if (!esriRequestRef.current) {
        esriRequestRef.current = await loadArcGISJSAPIModule('esri/request')
      }
      return esriRequestRef.current(session?.token ? `${toolUrl}?token=${session.token}` : toolUrl, { query: { f: 'json' }, responseType: 'json' })
    }).catch((error) => {
      checkErrorAndReportUtilityState(error)
    })
  }

  useEffect(() => {
    if (appContainer && errorStrings) {
      const onAnalysisCoreJobStatus = (e: AnalysisToolAppContainerCustomEvent<AnalysisGPJobStatus>) => {
        if (!runAnalysysDisabledRef.current && !analysisToolContainerRef.current) {
          appContainer.removeEventListener(AnalysisCoreEvents.JobStatus, onAnalysisCoreJobStatus)
          return
        }
        if (e?.detail?.submissionData) {
          if (toolJson.executionType === 'esriExecutionTypeSynchronous' && e?.detail?.jobInfo?.jobStatus === 'job-failed') {
            setValidationStatus(ValidityState.Error)
            setErrorMessage(errorStrings.jobCurrentParameters as string)
            handleJobSubmitedError()
          } else {
            notifyJobSubmited(appContainer, { ...e.detail, toolId })
          }
          setRunAnalysisDisabled(false)
        }
        if (runAnalysysDisabledRef.current && !analysisToolContainerRef.current) {
          appContainer.removeEventListener(AnalysisCoreEvents.JobStatus, onAnalysisCoreJobStatus)
        }
      }
      appContainer.addEventListener(AnalysisCoreEvents.JobStatus, onAnalysisCoreJobStatus)
    }
  }, [appContainer, toolId, errorStrings])

  const prepJobParamsForSubmission = (jobParams: AnalysisToolData) => {
    const serializedJobParams: AnalysisToolData = { ...jobParams }
    for (const param in serializedJobParams) {
      const parameterObject = serializedJobParams[param] as { [key: string]: AnalysisToolDataItem }
      if (isEmptyDataItem(parameterObject)) {
        delete serializedJobParams[param]
      }
    }
    return serializedJobParams
  }

  useEffect(() => {
    if (analysisToolData) {
      onToolDataChange(analysisToolData)
    }
  }, [analysisToolData])

  const runTask = async () => {
    const { valid, errorKeys } = await analysisToolContainer.validateTool()
    const allErrorKeys = Array.from(new Set([...errorKeys]))
    const status = valid ? ValidityState.Valid : ValidityState.Error
    setValidationStatus(status)
    if (status === ValidityState.Error) {
      setErrorMessage(allErrorKeys.length === 1 ? errorStrings[allErrorKeys[0]] as string : allErrorKeys.map((key) => errorStrings[key] as string))
      if (panelElementRef.current) {
        panelElementRef.current.scrollContentTo({ top: 0, behavior: 'auto' })
      }
      return
    }
    onToolDataChange({ detail: { toolData: analysisToolContainer?.toolData } })
    const { currentJobParams } = parameters.current
    if (currentJobParams !== undefined) {
      setRunAnalysisDisabled(true)

      const resultParams = getResultParams(convertedToolJson)
      const jobParamsPayload = prepJobParamsForSubmission(currentJobParams)

      try {
        let serviceInfoDetail = serviceInfo
        if (!serviceInfoDetail) {
          serviceInfoDetail = await getServiceInfo()
        }
        await executeJob(geoprocessor, {
          jobParams: lodash.cloneDeep(currentJobParams),
          jobParamsPayload: lodash.cloneDeep(jobParamsPayload),
          resultParams,
          gpMessages: resultParams.includes('processInfo') ? gpMessages as { [key: string]: string } : undefined,
          portal,
          toolName,
          analysisEngine: AnalysisEngine.Standard,
          analysisType: AnalysisType.Tool,
          containerElement: appContainer,
          toolUiParameters: parameters.current.toolUiParameters
        }, { ...convertedToolJson, serviceInfo: serviceInfoDetail }, getCustomToolUrlWithToken(toolUrl), webToolServerUrl)
        reportUtilityState(true)
      } catch (e) {
        setRunAnalysisDisabled(false)
        setValidationStatus(ValidityState.Error)
        const errorMessage = e.details?.type === CLIENT_THROWN_ERROR ? e.message : errorStrings.jobCurrentParameters
        setErrorMessage(errorMessage)
        if (panelElementRef.current) {
          panelElementRef.current.scrollContentTo({ top: 0, behavior: 'auto' })
        }
        handleJobSubmitedError()
      }
    }
  }

  useEffect(() => {
    if (!option.showHelpLink && toolHelpPopover.current) {
      toolHelpPopover.current.remove()
    }
  }, [option.showHelpLink])

  const [backButtonFocused, setBackButtonFocused] = useState(false)

  return (
    <div className='analysis-exb-custom-web-tool-container h-100 d-flex'>
      <CalciteFlowItem
        show-back-button={!disableBack}
        closable={false}
        onCalciteFlowItemBack={onBack}
        ref={(ref) => {
          panelElementRef.current = ref
          if (!disableBack && !backButtonFocused) {
            ref?.setFocus()
            setBackButtonFocused(true)
          }
        }}
      >
        <div
          slot="header-content"
          ref={headerElementRef}
        >
          {displayedToolName}
        </div>
        {option.showHelpLink && <CalciteAction
          label=""
          text=""
          icon="information"
          slot="header-actions-end"
          onClick={() => {
            if (option.link !== undefined && showHelp) {
              toolHelpPopover.current = showHelp(toolHelpPopover.current, {
                helpUrl: option.link,
                helpId: toolId,
                heading: displayedToolName,
                referenceElement: headerElementRef.current,
                isHelpFileExternalAsset: true,
                learnMoreBaseUrl: portal?.sourceJSON.helpBase,
                offsetDistance: 55,
                offsetSkidding: 10,
                learnMoreUrl: option.link
              })
              if (toolHelpPopover.current) {
                toolHelpPopover.current.helpSrcdoc = getColoredDesc(toolJson.description)
                toolHelpPopover.current.learnMoreBaseUrl = undefined
              }
            }
          }}
        ></CalciteAction>}
        {validationStatus === ValidityState.Error || validationStatus === ValidityState.Warning
          ? (<CalciteNotice
              open
              kind={validationStatus === ValidityState.Error ? 'danger' : 'warning'}
              closable
              scale="m"
              width="auto"
              onCalciteNoticeClose={() => { setValidationStatus(ValidityState.Valid) }}
            >
              {Array.isArray(errorMessage) && errorMessage.length > 0
                ? <ul slot="message">
                    {errorMessage.map((error) => <li>{error}</li>)}
                  </ul>
                : <div slot="message" dangerouslySetInnerHTML={{ __html: errorMessage as string }}></div>}
            </CalciteNotice>)
          : null}
        <div
          onKeyDown={(e) => { e.stopPropagation() }}
          ref={setAnalysisToolRef}
          className='custom-tool-container'
        />
        <CalciteButton
          slot='footer'
          loading={runAnalysisDisabled ? true : undefined}
          onClick={runTask}
          appearance='solid'
          kind='brand'
          width={disableBack ? 'full' : 'half'}
          alignment='center'
          scale='m'
        >
          {translate('run')}
        </CalciteButton>
        {!disableBack && <CalciteButton
          slot='footer'
          disabled={runAnalysisDisabled ? true : undefined}
          onClick={onBack}
          appearance='outline'
          kind='brand'
          width='half'
          alignment='center'
          scale='m'
        >
          {translate('back')}
        </CalciteButton>}
        <Alert
          css={alertStyle}
          autoFocus
          closable
          withIcon
          form="basic"
          open={!!utilityErrorMessage}
          onClose={() => { setUtilityErrorMessage('') }}
          text translate(utilityErrorMessage) : ''}
          type='warning'
        />
      </CalciteFlowItem>
      {!analysisToolAppLoaded && <Loading />}
    </div>
  )
}

export default CustomTool
